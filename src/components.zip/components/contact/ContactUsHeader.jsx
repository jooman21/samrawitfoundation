import React from 'react'


const ContactUsHeader = () => {
return (
    <>
        <div className="teamsHome_section container">

            <div className="teamSection_title">
                <h1 className='teamSection_title_h1'>Join Us</h1>
            </div>

            <div className="teams_moto">
                <h3 className='teams_moto_word'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est libero dolorem culpa, non fugiat quibusdam esse. Sit amet, dignissimos quo cumque expedita ab commodi aperiam ea itaque possimus enim dolorum.</h3>
            </div>

        </div>
    </>
  )
}    
export default ContactUsHeader