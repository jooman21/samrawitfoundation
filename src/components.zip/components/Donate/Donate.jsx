import React from 'react'
import './Donate.css'
import  { useState} from 'react'
const Donate = () => {
    const [toggleState, setToggleState] = useState(0);
    const toggleTab = (index) => {
      setToggleState(index);
    }
  return (
    <div className='donateSection'> <button className='donate' onClick={() => toggleTab(1)}>Donate</button>
    <div className={toggleState === 1 ? "footer__modal active-modal" : "footer__modal"}>
          <div className="footer__modal-content">
            <i onClick={() => toggleTab(0)} className='uil uil-times footer__modal-close'></i>
            <div className="infos">
             <ul className='account'>
              <li>
              <i className='uil uil-university'></i> &#160; <strong>Commercial bank of Ethiopia</strong>
                 <br></br>
                 Samrawit Foundation Account No: 1000551542778
              </li>
              <hr />
              <br />

              <li>
              <i className='uil uil-university'></i> &#160; <strong>Dashen Bank</strong>
                 <br></br>
                 Samrawit Foundation Account No: 0534334457011
              </li>
              <hr />
              <br />
             
              <li className='uil uil-university'>  &#160;  <strong>Telebirr fundraising account: Use telebirr platform, follow the following steps</strong>
                 <br />
                 <br />
              </li>
              <li>
              <i className='uil uil-check-circle checkcolor'></i> &#160; 1. Open your telebirr superapp
              </li>
              <li>
              <i className='uil uil-check-circle checkcolor'></i> &#160; 2. Click ‘’More’’
              </li>
              <li>
              <i className='uil uil-check-circle checkcolor'></i> &#160; 3. Click ‘’Fundraising’’
              </li>
              <li>
              <i className='uil uil-check-circle checkcolor'></i> &#160; 4. From list of Organizations choose ‘’Samrawit Foundation’’
              </li>
              <li>
              <i className='uil uil-check-circle checkcolor'></i> &#160; 5. ‘’Subscribe’’ the amount as you can to periodically donate
              </li>
              <br />
             </ul>
            </div>
          </div>
    </div>
</div>
  )
}

export default Donate