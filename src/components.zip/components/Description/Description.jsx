import React from 'react'
import './Description.css'

const Description = () => {
  return (
    <>
       <div className="foundation_discription ">
            <h1 className='dis'>‘’EMPOWERING HOPE, JOINING HANDS TO CHANGE THE LIVES OF DESTITUTE CHILDREN, MARGINALIZED ELDERS AND DESABLED PEOPLE’’</h1>
       </div>
    </>
  )
}

export default Description