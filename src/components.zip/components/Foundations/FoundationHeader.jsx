import React from 'react'
// import './Foundation.css'


const FoundationHeader = () => {
return (
    <>
        <div className="teamsHome_section container">

            <div className="teamSection_title">
                <h1 className='teamSection_title_h1'>The Founders</h1>
            </div>

            <div className="teams_moto">
                <h3 className='teams_moto_word'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat, magni voluptate! Beatae nihil id, atque corrupti blanditiis mollitia dolores nemo.</h3>
            </div>

        </div>
    </>
  )
}    

export default FoundationHeader