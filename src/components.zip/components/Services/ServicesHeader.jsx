import React from 'react'

const ServicesHeader = () => {
  return (
    <div className="teamsHome_section container">

        <div className="teamSection_title">
            <h1 className='teamSection_title_h1'>Our Services</h1>
    </div>

    <div className="teams_moto">
        <h3 className='teams_moto_word'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos maxime pariatur natus placeat quibusdam, fuga laudantium rerum nulla quod labore?</h3>
    </div>

    </div>
  )
}

export default ServicesHeader