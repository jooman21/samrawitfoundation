// Pics.jsx
const galleryImages = [
    {
        img: process.env.PUBLIC_URL + '/assets/family/samri02.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family//samri-02.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-1.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-03.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-09.png',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-06.png',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-07.png',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-08.png',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-05.png',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-10.png',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-12.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/service2.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/service3.png',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-14.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-14.jpg',
    },
    {
        img: process.env.PUBLIC_URL + '/assets/family/team-14.jpg',
    },
];

export default galleryImages;
