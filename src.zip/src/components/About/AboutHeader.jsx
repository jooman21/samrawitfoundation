import React from 'react'

function AboutHeader() {
  return (
    <div className="teamsHome_section container">

        <div className="teamSection_title">
            <h1 className='teamSection_title_h1'>About Us</h1>
    </div>

    <div className="teams_moto">
        <h2 className='teams_moto_word'>Samrawit Foundation was established to memorialize our late daughter Samrawit Tagel</h2>
    </div>

    </div>
  )
}

export default AboutHeader