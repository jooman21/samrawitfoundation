import React from 'react'
import './Gallaries.css'
function GallariesHome() {
  return (
    <>
        <div className="teamsHome_section container">

            <div className="teamSection_title founderHome">
                <h1 className='teamSection_title_h1 founderHome_h1'>Gallaries</h1>
            </div>

            <div className="teams_moto">
                <h2 className='teams_moto_word'>Facilitate destitute, excluded and vulnerable children, mothers and elder people in Ethiopia to have the opportunity to improve their lives and become productive citizens who contribute a positive change in their communities.</h2>
            </div>

        </div>
</>
  )
}

export default GallariesHome